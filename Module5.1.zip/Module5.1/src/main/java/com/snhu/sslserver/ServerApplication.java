package com.snhu.sslserver;

import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
    @RequestMapping("/hash")
    public String myHash(){
        // Initializes a try-catch block to handle any errors
        try {
            // Initializes two string vars to hold the cipherAlgorithm's name and the unique data string for the algorithm cipher. 
            String cipherAlgorithm = "SHA-256";
            String data = "Cristiano Miranda";

            // Initializes a new MessageDigest object using the defined cipherAlgorithm
            MessageDigest md = MessageDigest.getInstance(cipherAlgorithm);
    
            // Updates the MessageDigest object by using the bytes from the data var
            md.update(data.getBytes());

            // Calls the digest method on the MessageDigest object and stores the gathered bytes in an array
            byte[] bytesArray = md.digest();
    
            // Initializes a checkSum string buffer to hold the hexCode value of the bytesArray
            StringBuffer checkSum = new StringBuffer();
    
            // Loops through the bytesArray
            for (int i = 0; i < bytesArray.length; i++) {
                // Appends the hexValue of the element located at the current index of the bytesArray to the checkSum string buffer
                checkSum.append(Integer.toHexString(0xFF & bytesArray[i]));
            }

            // Returns a formatted string containing the initial data string, cipher algorithm name, and the final checksum string.
            return String.format("<p>data: %s\n<p>Name of Cipher Algorithm Used: %s CheckSum Value: %s", data, cipherAlgorithm, checkSum);
        } catch (Exception e) { // Catches any error
            // Prints the error to the console
            System.out.println(e.getMessage());
            // Returns failed to indicate the generator failed
            return "failed";
        }
    }
}
